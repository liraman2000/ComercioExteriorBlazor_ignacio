﻿namespace ComercioExteriorBlazor
{
    public class InitialApplicationState
    {
        public bool IsAuthenticated { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }

    }
}
