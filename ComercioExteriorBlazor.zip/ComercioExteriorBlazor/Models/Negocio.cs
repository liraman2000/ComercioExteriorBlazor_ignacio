﻿namespace ComercioExteriorBlazor.Models
{
    public class Negocio
    {
        public string Id { get; set; }
        public string Descripcion { get; set; }
        public string RFC { get; set; }
        public string Activo { get; set; }
    }
}
