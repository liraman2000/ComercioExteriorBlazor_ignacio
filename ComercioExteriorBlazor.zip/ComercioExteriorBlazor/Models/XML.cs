﻿namespace ComercioExteriorBlazor.Models
{
    public class XML
    {
        public int Id { get; set; }
        public string UUID { get; set; }
        public string Pedimento { get; set; }
        public  string Xml_doc { get; set; }
    }
}
