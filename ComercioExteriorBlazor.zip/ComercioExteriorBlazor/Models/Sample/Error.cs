using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Blazor.Models.Sample
{
    public partial class Error
    {
    }
}
