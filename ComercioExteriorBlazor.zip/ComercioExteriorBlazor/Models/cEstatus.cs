﻿namespace ComercioExteriorBlazor.Models
{
    public class cEstatus
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public int Activo { get; set; }
    }
}
