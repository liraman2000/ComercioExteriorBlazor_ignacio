﻿namespace ComercioExteriorBlazor.Models
{
    public class Perfil
    {
        public int Id { get; set; }
        public string? Descripcion { get; set; }
        public string Activo { get; set; }
    }
}
