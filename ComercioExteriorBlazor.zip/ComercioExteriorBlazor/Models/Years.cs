﻿namespace ComercioExteriorBlazor.Models
{
    public class Years
    {
        public int Year { get; set; }        
    }
}
