﻿namespace ComercioExteriorBlazor.Models
{
    public class Observaciones
    {
        public int Id { get; set; }
        public int IdIncidencia { get; set; }
        public string Descripcion { get; set; }
        public string FechaCreacion { get; set; }
        public int IdUsuario { get; set; }
    }
}
